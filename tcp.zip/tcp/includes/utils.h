
int p3n(long n);

int p6n(long n);

int p3c(int n);
int p6c(int n);

int parrayi(int a[],int length);

int getline2(char line[],int lim);

int copys(char to[],char from[]);

int lequal(long a,long b);
int lnequal(long a,long b);

int reverse_str(char s[]);
int cofs(char *s,char c);
int lower(char uc);
