/**
 * Author: Jeremy Yu <ccpalettes@gmail.com>
 * 
 * Solution for Exercise 1-7, Chapter1.
 */

#include <stdio.h>

int main(void)
{
    printf("The value of EOF is %d.\n", EOF);
    return 0;
}