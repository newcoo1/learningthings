/**
 * Author: Jeremy Yu <ccpalettes@gmail.com>
 * 
 * Solution for Exercise 1-1, Chapter1.
 */

#include <stdio.h>

int main(void)
{
    printf("hello world!\n");
    return 0;
}