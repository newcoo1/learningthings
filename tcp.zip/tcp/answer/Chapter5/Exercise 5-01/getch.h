/**
 * Author: Jeremy Yu <ccpalettes@gmail.com>
 * 
 * Solution for Exercise 5-01, Chapter5.
 */

int getch(void);
void ungetch(int);