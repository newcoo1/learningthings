/**
 * Author: Jeremy Yu <ccpalettes@gmail.com>
 * 
 * Solution for Exercise 5-16, Chapter5.
 */

char *alloc(int);
void afree(char *p);