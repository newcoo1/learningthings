/**
 * Author: Jeremy Yu <ccpalettes@gmail.com>
 * 
 * Solution for Exercise 5-16, Chapter5.
 */

int numcmp(char *, char *);
int strcmpignore(char *, char *);